package prueba;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controlador {

	protected static final Component JFrame = null;
	private Vista vista;
	private Modelo model;

	public Controlador(Vista vista, Modelo mode) {
		this.vista = vista;
		this.model = mode;
		initEventHandler();
	}

	private void initEventHandler() {
		// TODO Auto-generated method stub
		vista.getPrincipal().append(Modelo.mostrarContenidoPrincipal("ficherin"));
		ActionListener anyadirActionListener = new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				String TextoAnyadir = vista.getTextañadir().getText();

				vista.getTxtfinal().append(Modelo.mostrarContenidoPrincipal("ficherin"));
				vista.getPrincipal().append(Modelo.mostrarContenidoPrincipal("ficherin"));
			}
		};
		vista.getBotonAnyadir().addActionListener(anyadirActionListener);

		ActionListener nuevoActionListener = new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String palabraString = vista.getTextoBuscar().getText();
				int num = Modelo.buscarTexto(palabraString);
				JOptionPane.showMessageDialog(JFrame, num);
				
			}
		};

		vista.getBtnBuscar().addActionListener(nuevoActionListener);
		
	}

}
