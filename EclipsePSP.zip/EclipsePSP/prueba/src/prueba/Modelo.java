package prueba;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.StringTokenizer;

/*     JFileChooser j = new JFileChooser();
        j.showOpenDialog(j);
        */
public class Modelo {

	private static String lecturaString = "ficherin";
	private static String EscrituraString = "prueba.txt";

	public static String mostrarContenidoPrincipal(String ruta) {
		String texto = "";
		try (FileReader fileReader = new FileReader(ruta)) {
			int caracterLeido = fileReader.read();
			while (caracterLeido != -1) {
				char caracter = (char) caracterLeido;
				caracterLeido = fileReader.read();
				texto += caracter;
			}
		} catch (IOException ex) {
			System.err.println("Error al leer el archivo");
			ex.printStackTrace();
		}
		return texto;
	}

	/*
	 * public static String anyadirTexto(String text) { String texto = ""; try {
	 * 
	 * FileWriter fw = new FileWriter(lecturaString); BufferedWriter bw = new
	 * BufferedWriter(fw); FileReader fr = new FileReader(lecturaString);
	 * BufferedReader br = new BufferedReader(fr);
	 * 
	 * String linea = br.readLine();
	 * 
	 * while(linea!=null){ bw.write(linea); bw.newLine(); linea = br.readLine(); }
	 * 
	 * bw.write(text + "\n"); br.close(); fr.close(); bw.close(); fw.close();
	 * 
	 * } catch (IOException ex) { System.err.println("Error al leer el archivo");
	 * ex.printStackTrace(); } return texto; }
	 */

	public static int buscarTexto(String palabra) {
		String pal = palabra;
		int contadorPalabras = 0;
		try {
			FileReader fr = new FileReader("ficherin");
			BufferedReader br = new BufferedReader(fr);
			String linea = br.readLine();

			String[] lineas;
			do {
				lineas = linea.split(" ");
				for (int i = 0; i < lineas.length; i++) {
					if (lineas[i].indexOf(palabra)!=-1) {
						contadorPalabras++;
					}
				}
				linea=br.readLine();
			} while (linea!=null);

			br.close();
			fr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return contadorPalabras;

	}

}
