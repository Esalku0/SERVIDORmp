package prueba;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class Vista extends JFrame {

	private JPanel contentPane;
	private JTextField txtañadir;
	public JTextArea texto;
	private JTextArea txtfinal;
	private JButton btnAñadir;
	private JTextField txtBuscarPalabra;
	private JTextField txtReemplazar;
	private JButton btnBuscarPalabra;
	private JButton btnReemplazar;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vista() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 739, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(60, 11, 508, 79);
		contentPane.add(scrollPane);

		texto = new JTextArea();
		scrollPane.setViewportView(texto);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(60, 250, 596, 122);
		contentPane.add(scrollPane_1);

		txtfinal = new JTextArea();
		scrollPane_1.setViewportView(txtfinal);

		txtañadir = new JTextField();
		txtañadir.setBounds(60, 174, 86, 20);
		contentPane.add(txtañadir);
		txtañadir.setColumns(10);

		btnAñadir = new JButton("añadir");
		btnAñadir.setBounds(155, 173, 89, 23);
		btnAñadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}});
		contentPane.add(btnAñadir);
	
		
		txtBuscarPalabra = new JTextField();
		txtBuscarPalabra.setBounds(254, 174, 86, 20);
		txtBuscarPalabra.setColumns(10);
		contentPane.add(txtBuscarPalabra);
		
		btnBuscarPalabra = new JButton("buscar");
		btnBuscarPalabra.setBounds(350, 173, 89, 23);
		contentPane.add(btnBuscarPalabra);
		
		txtReemplazar = new JTextField();
		txtReemplazar.setBounds(449, 174, 86, 20);
		txtReemplazar.setColumns(10);
		contentPane.add(txtReemplazar);
		
		btnReemplazar = new JButton("reemplazar");
		btnReemplazar.setBounds(545, 173, 89, 23);
		contentPane.add(btnReemplazar);

		setVisible(true);
	}

	public JTextArea getPrincipal() {
		return texto;
	}

	public JTextArea getTxtfinal() {
		return txtfinal;
	}

	public JTextField getTextañadir() {
		return txtañadir;
	}

	public JButton getBotonAnyadir() {
		return btnAñadir;
	}
	
	
	public JTextField getTextoBuscar() {
		return txtBuscarPalabra;
	}
	
	public JButton getBtnBuscar() {
		return btnBuscarPalabra;
	}
	
	public JButton getBtnReemplazar() {
		return btnReemplazar;
	}
	public JTextField getTextoReemplazar() {
		return txtReemplazar;
	}
	
	
	
}
