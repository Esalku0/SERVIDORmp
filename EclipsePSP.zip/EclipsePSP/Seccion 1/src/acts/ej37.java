package acts;

import java.util.Scanner;

public class ej37 {

	private static void CalculaSalario() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Dime los años de trabajo: ");
		int años = sc.nextInt();

		if (años < 1) {
			System.out.println("Desarrollador Junior L1 – 15000-18000");
		} else if (años >= 1 && años <= 2) {
			System.out.println("Desarrollador Junior L2 – 18000-22000");
		} else if (años >= 3 && años <= 5) {
			System.out.println("Desarrollador Senior L1 – 22000-28000");
		} else if (años >= 5 && años <= 8) {
			System.out.println("Desarrollador Senior L2 – 28000-36000");
		} else {
			System.out.println("Analista / Arquitecto. Salario a convenir en base a rol");
		}

	}

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		CalculaSalario();
	}

}
