package acts;

import java.util.Scanner;

public class ej38 {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		Scanner entrada= new Scanner(System.in);

		System.out.print("primer numero ");
		int primero = entrada.nextInt();

		System.out.print("segundos numero ");
		int segundo = entrada.nextInt();

		for (int i = primero; i <= segundo; i++) {
			System.out.print(i + "\n");
			
			if (i % 1 == 0) {
				System.out.println("Es primo");
			}else {
				System.out.println("No es primo");
			}
		}

	}

}
