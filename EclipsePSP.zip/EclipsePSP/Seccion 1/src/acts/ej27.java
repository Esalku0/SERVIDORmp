package acts;

import java.time.Year;
import java.util.Scanner;

public class ej27 {

	public static char CalcularLetraDNI(String DNI) {
		String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
		int dni = Integer.parseInt(DNI);
		int index = dni - (Math.abs(dni/23)*23);
		return letras.charAt(index);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Introduce DNI sin letra: ");
		Scanner leer = new Scanner(System.in);
		
		
		char letra = CalcularLetraDNI(leer.next());
		System.out.println("Su letra es: " + letra);
	

}}

