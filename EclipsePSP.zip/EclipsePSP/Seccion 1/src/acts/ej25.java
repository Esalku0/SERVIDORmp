package acts;

import java.util.Random;
import java.util.Scanner;

public class ej25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.print("Dime un numero entre 1 y 10: ");
		int numero1 = sc.nextInt();
		System.out.print("Dime otro numero entre 1 y 10: ");
		int numero2 = sc.nextInt();
		System.out.print("Dime otro numero entre 1 y 10: ");
		int numero3 = sc.nextInt();

		// Importamos el metodo random y luego creamos una instancia de random
		Random random = new Random();
		// Usando esto nos saca un valor aleatorio entre 10 y 1
		int valor = random.nextInt(10 + 1);


		
		if (numero1==valor || numero2==valor || numero3==valor) {
			
			System.out.println("ENHORABUENA HAS ACERTADO ");
			System.out.println("------------------------- ");
			System.out.println("Elije un premio entre estos 3: ");
			System.out.println("1- Skin del lol ");
			System.out.println("2- Juego a elegir ");
			System.out.println("3- Periferico aleatorio ");
			int eleccion = sc.nextInt();
			
			switch (eleccion) {
			  case 1:
			    System.out.println("Has ganado una skin en el lol!! ");
			    break;
			  case 2:
			    System.out.println("Ganaste un juego aleatorio!!!");
			    break;
			  case 3:
			    System.out.println("Ganaste un Periferico razer!! ");
			    break;
			}
		}else {
			System.out.println("No hubo suerte caballero... El numero ganado era el: " + valor);
		}
		
		
		
		
	}

}