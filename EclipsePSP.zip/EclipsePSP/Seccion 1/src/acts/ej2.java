package acts;

import java.util.Scanner;

public class ej2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		 System.out.print("Dime tu nombre: ");
		 
		 String userName = sc.nextLine();
		 System.out.print("Hola: " + userName);
		 
	}

}
