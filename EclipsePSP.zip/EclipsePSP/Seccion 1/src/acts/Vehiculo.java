package acts;

public class Vehiculo {

	private String tipo;
	private String modelo;
	private String marca;
	
	
	public Vehiculo(String ti, String mod, String mar) {
		this.tipo=ti;
		this.modelo=mod;
		this.marca=mar;
	}


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	
	
	
	
}
