package acts;

import java.util.Scanner;

public class ej3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner sc = new Scanner(System.in);
		 System.out.print("Dime el primer numero: ");
		 int num1 = sc.nextInt();
		 
		 System.out.print("Dime el segundo numero: ");
		 int num2 = sc.nextInt();
		 
		 int suma = num1 + num2;
		 
		 System.out.println(suma);
	}

}
