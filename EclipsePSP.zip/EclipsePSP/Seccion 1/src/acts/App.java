package acts;

public class App {

	private String frase;

	public App(String frase) {
		super();
		this.frase = frase;
	}

	public App() {

	}

	public void sayHello() {
		System.out.println("HOLA MUNDO");
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}

}
