package acts;

import java.util.Iterator;

public class ej33 {

	private static int SumaPares(int limite) {
		
		int acumulador=0;
		
		for (int i = 0; i <= limite; i++) {
			if (i%2==0) {
				acumulador+=i;
			}
		}
		return acumulador;
	}
	
	
	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		
		
	
		
		System.out.println(	SumaPares(5));
	}

}
