package acts;

import java.util.Iterator;

public class ej35 {

	private static int CalculaPequeños(int numeros[]) {
		int pequeño = 50000000;

		for (int i = 0; i < numeros.length; i++) {
			if (numeros[i] < pequeño) {
				pequeño = numeros[i];
			}
		}
		return pequeño;
	}

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		
		int[] numeros = {153, 62, 234, 12, 543, 55, 34256, 34, 10};
		
	
	System.out.println(	CalculaPequeños(numeros));	
	}

}
