package acts;

public class ej28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Vehiculo coche = new Vehiculo("coche", "K324234F", "SEAT");
		Vehiculo moto = new Vehiculo("motocicleta", "SD453345G", "VESPA");
		Vehiculo camion = new Vehiculo("camion", "434342234FGH", "CITROEN");
		
		System.out.println("El Vehiculo es un " +  coche.getTipo() +  " marca " +  coche.getMarca() + " modelo "+ coche.getModelo());
		
		System.out.println("El Vehiculo es un " +  moto.getTipo() +  " marca " +  moto.getMarca() + " modelo "+ moto.getModelo());
		
		System.out.println("El Vehiculo es un " +  camion.getTipo() +  " marca " +  camion.getMarca() + " modelo "+ camion.getModelo());
	}

}
