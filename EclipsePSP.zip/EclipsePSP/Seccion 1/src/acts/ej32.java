package acts;

import java.lang.reflect.Array;

public class ej32 {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		
	String[] compañeros = {"Santiago", "Gabrielin", "Rafael", "Yo", "TheFlush"};
	
	for (int i = 0; i < compañeros.length; i++) {
		System.out.println(compañeros[i]);
	}
	
	
	}

}
