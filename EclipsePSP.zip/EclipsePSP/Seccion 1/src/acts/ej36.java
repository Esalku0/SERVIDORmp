package acts;

import java.util.Iterator;
import java.util.Scanner;

public class ej36 {

	private static void InversionNumeros() {

		Scanner sc = new Scanner(System.in);
		int num;
		int[] numeros = new int[5];
		int[] revers = new int[5];

		for (int i = 0; i < numeros.length; i++) {
			System.out.println("Dime un numero: ");
			num = sc.nextInt();
			numeros[i] = num;
		}

		int j = 4;
		while (j >= 0) {

			System.out.println(numeros[j]);
			j--;
		}
	}

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		InversionNumeros();
	}

}
