package acts;

public class ej31 {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

		
		App apliApp = new App(null);
		
		
		apliApp.sayHello();
	}

}
