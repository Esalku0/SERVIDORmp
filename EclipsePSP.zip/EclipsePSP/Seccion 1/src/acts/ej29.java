package acts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ej29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String tipo, marca, modelo;
		Vehiculo[] arrayVehiculos = new Vehiculo[5];
		Scanner sc = new Scanner(System.in);

		for (int i = 0; i < 5; i++) {
			System.out.print("Tipo: ");
			tipo = sc.next();
			System.out.print("Marca: ");
			marca = sc.next();
			System.out.print("Modelo: ");
			modelo = sc.next();

			Vehiculo vehiculo = new Vehiculo(tipo, marca, modelo);
			arrayVehiculos[i] = vehiculo;

		}

		for (Vehiculo vehiculoahora : arrayVehiculos) {
			System.out.println(vehiculoahora.toString());
		}

		sc.close();
		
		
	}

}
