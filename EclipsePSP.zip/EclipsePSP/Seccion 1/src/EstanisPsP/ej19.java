package EstanisPsP;

public class ej19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char I;

		for (I = 0; I < 255; I++) {

			System.out.print(I);
		}
	}

}
