package EstanisPsP;

public class ej23 {

	public static void main(String[] args) {
		// TODO Esbozo de método generado automáticamente

	}

}
