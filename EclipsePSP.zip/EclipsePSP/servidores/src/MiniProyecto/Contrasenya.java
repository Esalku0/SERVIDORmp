package MiniProyecto;

import java.io.Serializable;

public class Contrasenya implements Serializable {

	public Contrasenya(String textoPlano, String contrasenyaEncriptada) {
		this.textoPlano = textoPlano;
		this.contrasenyaEncriptada = contrasenyaEncriptada;
	}
	public Contrasenya() {}

	private static final long serialVersionUID = 1L;

	private String textoPlano;
	private String contrasenyaEncriptada;

	public String getTextoPlano() {
		return textoPlano;
	}

	public void setTextoPlano(String textoPlano) {
		this.textoPlano = textoPlano;
	}

	public String getContrasenyaEncriptada() {
		return contrasenyaEncriptada;
	}

	public void setContrasenyaEncriptada(String contrasenyaEncriptada) {
		this.contrasenyaEncriptada = contrasenyaEncriptada;
	}

	@Override
	public String toString() {
		return "Contrasenya [textoPlano=" + textoPlano + ", contrasenyaEncriptada=" + contrasenyaEncriptada + "]";
	}

}
