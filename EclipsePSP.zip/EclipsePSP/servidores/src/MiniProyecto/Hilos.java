package MiniProyecto;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class Hilos implements Runnable {
	BufferedReader bfr;
	PrintWriter pw;
	Socket socket;

	public Hilos(Socket conexion) {
	}

	public String Codificar(String contr) {
		String cadenaString="";
		for (int x = 0; x < contr.length(); x++)
			cadenaString+= contr.codePointAt(x+1);
		;
		return cadenaString;
	}

	
	public void run() {

		Socket socket;
		try {
			socket = new Socket("localhost", 5555);




			Contrasenya co1 = new Contrasenya("dfssdf","fsdf");
			ObjectOutputStream outObjeto = new ObjectOutputStream(socket.getOutputStream());
			outObjeto.writeObject(co1);
		

			
			ObjectInputStream inObjeto = new ObjectInputStream(socket.getInputStream());
			Contrasenya cont = (Contrasenya) inObjeto.readObject();
			
			String codificado=Codificar(cont.getTextoPlano());
			
			co1.setTextoPlano(cont.getTextoPlano());
			co1.setContrasenyaEncriptada(codificado);
			outObjeto.writeObject(co1);
			
			inObjeto.close();
			outObjeto.close();
			socket.close();
			
		
		} catch (IOException e) {

			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}