package ejs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ClientePeticionMultiHilo implements Runnable {
	BufferedReader bfr;
	PrintWriter pw;
	Socket socket;

	public ClientePeticionMultiHilo(Socket socket) {
		this.socket = socket;
	}

	public static int extraerNumero(String linea) {
		int numero;
		try {
			numero = Integer.parseInt(linea);
		} catch (NumberFormatException e) {
			numero = 0;
		}
		if (numero >= 100000000) {
			numero = 0;
		}
		return numero;
	}

	public static int calcular(String op, String n1, String n2) {
		int resultado = 0;
		char simbolo = op.charAt(0);
		int num1 = extraerNumero(n1);
		int num2 = extraerNumero(n2);
		if (simbolo == '+') {
			resultado = num1 + num2;
		}else if (simbolo == '-') {
			resultado = num1 - num2;
		} else if (simbolo == '*') {
			resultado = num1 * num2;
		}else {
			resultado = num1 / num2;
		}
		return resultado;
	}

	public void run() {
		try {
			InputStream is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			bfr = new BufferedReader(isr);
			OutputStream os = socket.getOutputStream();
			pw = new PrintWriter(os);
			String linea = bfr.readLine();
			System.err.println("SERVIDOR >>> Lee datos para la operacion");
			String num1 = bfr.readLine();
			String num2 = bfr.readLine();
			String NOMBRE = bfr.readLine();
			System.err.println("SERVIDOR >>> Realiza la operacion");
			Integer result = calcular(linea, num1, num2);
			System.err.println("SERVIDOR >>> Devuelve resultado");
			pw.write(result.toString() + "\n");
			System.out.println(NOMBRE);
			pw.flush();
			System.err.println("SERVIDOR >>> Espera nueva peticion");
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println("SERVIDOR >>> Error.");
		}
	}
}