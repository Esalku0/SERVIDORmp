package ejs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorObjeto {
	public static void main(String[] args) throws IOException {
		System.err.println("SERVIDOR >>> Arranca el servidor, espera peticion");
		ServerSocket socketEscucha = null;
		try {
			socketEscucha = new ServerSocket(1234);
		} catch (IOException e) {
			System.err.println("SERVIDOR >>> Error");
			return;
		}

		Socket conexion = socketEscucha.accept();
		System.err.println("SERVIDOR >>> Conexion recibida!");
		System.err.println("SERVIDOR >>> Lee datos para la operacion");
		ObjectInputStream inObjeto = new ObjectInputStream(conexion.getInputStream());
		try {
			Libro li = (Libro) inObjeto.readObject();
			li.setAutor("Pablo no sabe hacer strings ni .equals");
			System.err.println("SERVIDOR >>> " + li.toString());
		

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.err.println("SERVIDOR >>> Espera nueva peticion");
		
		Libro libro = new Libro("santi", "santi asustade en el gmod");

		ObjectOutputStream outObjeto = new ObjectOutputStream(conexion.getOutputStream());
		outObjeto.writeObject(libro);
		
		
		conexion.close();
		inObjeto.close();
//		outObjeto.close();
	}
}
