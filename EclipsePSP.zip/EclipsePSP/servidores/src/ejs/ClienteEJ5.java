package ejs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ClienteEJ5 {
	public static void main(String[] args) throws IOException {
		System.out.println("CLIENTE >>> Arranca cliente");
		System.out.println("CLIENTE >>> Conexion al servidor");
		Socket socket = new Socket("localhost", 1234);
		System.out.println("CLIENTE >>> Preparado canal para recibir resultado");

		System.out.println("CLIENTE >>> Envio de datos...");

		Libro libro = new Libro("pepe", "pues pepe caminando en un pepeega");
		ObjectOutputStream outObjeto = new ObjectOutputStream(socket.getOutputStream());
		outObjeto.writeObject(libro);

		System.out.println("CLIENTE >>> Recibido");
		ObjectInputStream inObjeto = new ObjectInputStream(socket.getInputStream());
		try {
			Libro li = (Libro) inObjeto.readObject();
			System.out.println("SERVIDOR >>> " + li.toString());

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}


		//IMPORTANTE PONER CLOSE SI NO NO FUNCIONA
		socket.close();
		inObjeto.close();
		outObjeto.close();
	}
}