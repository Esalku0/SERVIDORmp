package miniproyecto;

public class Mina {
	
	private int stock;

	Mina(int stock) {
		this.stock = stock;
	}

	public int getStock() {
		return stock;
	}
	
	public void setStock(int stock) {
		this.stock = stock;
	}
	
}
