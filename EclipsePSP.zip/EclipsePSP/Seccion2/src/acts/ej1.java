package acts;

import java.util.Scanner;

public class ej1 {

	public static int ejecutar(int num1, int num2) {

		int suma = 0;

		for (int i = num1; i <= num2; i++) {
			suma += i;
		}
		
		return suma;
	}

	public static void main(String[] args) {
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);

		int resu = ejecutar(num1, num2);
		System.out.println(resu);

	}
}
