package acts;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

//implementar una modificación del programa número 4 para que llame dos veces 
//consecutivas al programa 3 (con números distintos), lea los resultados de los ficheros 
//generados y los muestre por pantalla

public class Act5_Lanzador{
	public void lanzarSumador(Integer n1, Integer n2) {
		String clase = "acts.Act3_Sumador";
		try {
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classPath = System.getProperty("java.class.path");
			System.out.println(classPath);
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classPath);
			command.add(className);
			command.add(n1.toString());
			command.add(n2.toString());

			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.start();
			process.waitFor();//EL WAIT FOR ESPERA A QUE ACABE EL PROCESO PARA EJECUTAR LO SIGUIENTE!!!!
			// System.out.println(process.exitValue());
			try {
				FileReader fr = new FileReader("./fitxer.txt");
				int letra = fr.read();
				int let = fr.read();
				char caracter = 0;
				char caract = 0;
				while (letra != -1) {
					caracter = (char) letra;
					System.out.print(caracter);
					letra = fr.read();
				}
				while (let != -1) {
					caract = (char) letra;
					System.out.println(caract);
					let = fr.read();
				}
				fr.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Act4_Lanzador l = new Act4_Lanzador();
		l.lanzarSumador(1, 50);
		l.lanzarSumador(51, 100);

	}

}
