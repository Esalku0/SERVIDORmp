package acts;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Act6_7_LanzadorREDIRECT {
	public void lanzarSumador(Integer n1, Integer n2) {
		String clase = "acts.Act1_Sumador";
		try {
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classPath = System.getProperty("java.class.path");
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classPath);
			command.add(className);
			command.add(n1.toString());
			command.add(n2.toString());

			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.redirectOutput(new File("fitxerin.txt")).start(); //EL REDIRECT OUTPUT ES PARA ENVIAR LA INFORMACION DE ESTO A UN FICHERO!!!!
			process.waitFor();
			System.out.println(process.exitValue());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Act6_7_LanzadorREDIRECT l = new Act6_7_LanzadorREDIRECT();
		l.lanzarSumador(1, 52);
		l.lanzarSumador(80, 100);
		System.out.println("Ok");

	}

}
