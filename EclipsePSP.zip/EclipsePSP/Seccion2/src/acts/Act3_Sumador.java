package acts;

import java.io.FileWriter;
import java.io.IOException;

public class Act3_Sumador {
	public int sumar(int n1, int n2) {
		System.out.println("Sumar los numeros comprendidos entre " + n1 + " y " + n2);
		int suma = 0;
		for (int intento = n1; intento <= n2; intento++) {
			suma += intento;
		}
		return suma;
	}

	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("./fitxer.txt");
			Act3_Sumador s = new Act3_Sumador();
			int n1 = Integer.parseInt(args[0]);
			int n2 = Integer.parseInt(args[1]);
			int resultado = s.sumar(n1, n2);
			System.out.println("Resultado de este sumador: " + resultado);
			fw.write(String.valueOf(resultado));
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
