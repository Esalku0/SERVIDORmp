package acts;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Act2_Lanzador {
	public void lanzarSumador(Integer n1, Integer n2) {
		String clase = "acts.Act1_Sumador";
		try {
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classPath = System.getProperty("java.class.path");
			String className = clase;
			
			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classPath);
			command.add(className);
			command.add(n1.toString());
			command.add(n2.toString());
			
			
			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.inheritIO().start(); //EL INHERITIO SIRVE PARA MOSTRAR POR CONSOLA!!!!
			process.waitFor();
			System.out.println(process.exitValue());//EL 0 INDICA QUE TODO HA FUNCIONADO BIEN!!!!!!!!!!!!!!!!
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Act2_Lanzador l = new Act2_Lanzador();
		l.lanzarSumador(1, 52);
		l.lanzarSumador(80, 100);
		System.out.println("Ok");
	}

}
