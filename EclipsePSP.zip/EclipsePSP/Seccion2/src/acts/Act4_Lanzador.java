package acts;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Act4_Lanzador {
	public void lanzarSumador(Integer n1, Integer n2) {
		String clase = "acts.Act3_Sumador";
		try {
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classPath = System.getProperty("java.class.path");
			System.out.println(classPath);
			String className = clase;

			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classPath);
			command.add(className);
			command.add(n1.toString());
			command.add(n2.toString());


			ProcessBuilder builder = new ProcessBuilder(command);
			Process process = builder.start();
			process.waitFor();
			//System.out.println(process.exitValue());
			try {
				FileReader fr = new FileReader("./fitxer.txt");
				int letra = fr.read();
				//char caracter = 0;
				while (letra != -1) {
					char caracter = (char) letra;
					System.out.print(caracter);
					letra = fr.read();
				}
				fr.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Act4_Lanzador l = new Act4_Lanzador();
		l.lanzarSumador(1, 50);
		

	}

}
