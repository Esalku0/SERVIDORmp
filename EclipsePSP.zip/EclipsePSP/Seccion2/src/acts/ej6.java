package acts;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ej6 {


	public static void ejecutar(int num1, int num2) {
		try {
			String clase = "acts.ej1";
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			String className = clase;
			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(String.valueOf(num1));
			command.add(String.valueOf(num2));
			System.out.println(command);
			ProcessBuilder builder = new ProcessBuilder(command);
			Process p = builder.inheritIO().start();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ejecutar(1,67);


	}

}
