package acts;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class programa {

	public static double calcularPosicion(String nom, double posicionNEO, double velocidadNEO) {
		double posicionTierra = 1;
		double velocidadTierra = 100;
		for (int i = 0; i < (50 * 365 * 24 * 60 * 60); i++) {
			posicionNEO = posicionNEO + velocidadNEO * i;
			posicionTierra = posicionTierra + velocidadTierra * i;
		}
		
		double resultado = 100 * Math.random()
				* Math.pow(((posicionNEO - posicionTierra) / (posicionNEO + posicionTierra)), 2);

		String cad = String.valueOf(resultado);
		// cad = cad.substring(0, 5);
		//IMPORTANTE PARA SACAR 2 DECIMALES SANTIAGUIN
		cad=String.format("%.2f", resultado);
		//Double prob = Double.parseDouble(cad);
		long startTime = System.nanoTime();

		long endTime = System.nanoTime() - startTime;

		if (resultado >= 10) {
			System.out.println(cad);
			System.err.println("VAMOS A MORIR TODOSSSS");
			System.out.println("Duracion: " + (endTime - startTime)/1e9 + " s");

		} else {
			System.out.println(cad);
			System.out.println("No se preocupen estamos bien");
			System.out.println("Duracion: " + (endTime - startTime)/1e9 + " s");
		}

		try {
			File fichero = new File(nom + ".txt");
			FileWriter fw = new FileWriter(fichero);
			BufferedWriter bw = new BufferedWriter(fw);
			String lineaString = String.valueOf(resultado);
			bw.write(lineaString);

			bw.close();
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultado;
	}

	public static void main(String[] args) {

		Double num1 = Double.parseDouble(args[1]);
		Double num2 = Double.parseDouble(args[2]);

		calcularPosicion(args[0], num1, num2);

	}

}
