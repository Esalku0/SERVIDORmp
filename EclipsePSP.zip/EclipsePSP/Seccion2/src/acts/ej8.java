package acts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ej8 {

	public static void ejecutar(String nombre, Double num1, Double num2) {
		try {
			String clase = "acts.programa";
			String javaHome = System.getProperty("java.home");
			String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
			String classpath = System.getProperty("java.class.path");
			String className = clase;
			List<String> command = new ArrayList<>();
			command.add(javaBin);
			command.add("-cp");
			command.add(classpath);
			command.add(className);
			command.add(String.valueOf(nombre));
			command.add(String.valueOf(num1));
			command.add(String.valueOf(num2));
			ProcessBuilder builder = new ProcessBuilder(command);
			Process p = builder.inheritIO().start();

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public static void main(String[] args) {

		int processors = Runtime.getRuntime().availableProcessors();
		System.out.println("CPU cores: " + processors);

		long startTime = System.nanoTime();

		File f1 = new File("NEOs.txt");

		FileReader fr;

		try {
			fr = new FileReader(f1);
			BufferedReader br = new BufferedReader(fr);
			String linea;
			linea = br.readLine();

			for (int i = 0; i < processors; i++) {

				String arr[] = linea.split(",");
				System.out.println(arr[0] + arr[1] + arr[2]);

				Double num1 = Double.parseDouble(arr[1]);
				Double num2 = Double.parseDouble(arr[2]);
				System.out.println("----------------------------");
				ejecutar(arr[0], num1, num2);
				linea = br.readLine();

			}

			System.out.println("TIEMPO TOTAL DE EJECUCION: " + startTime);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
