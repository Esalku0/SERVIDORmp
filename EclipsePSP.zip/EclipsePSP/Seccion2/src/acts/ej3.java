package acts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class ej3 {

	public static int ejecutar(int num1, int num2) {

		int suma = 0;

		for (int i = num1; i <= num2; i++) {
			suma += i;
		}
		return suma;
	}

	public static void main(String[] args) {
		try {
			File f1 = new File("./resultado.txt");
			FileWriter fw = new FileWriter(f1);
			BufferedWriter bw = new BufferedWriter(fw);
			
			File f2 = new File("./resultado2.txt");
			FileWriter filew = new FileWriter(f2);
			BufferedWriter bufferw = new BufferedWriter(filew);
			
			

			int num1 =1;
			int num2 = 64;
			
			int resu = ejecutar(num1, num2);
			bw.write(resu + "\n");
			bufferw.write(resu + "\n");
			bw.close();
			bufferw.close();
			fw.close();
			filew.close();

			
			FileReader frFileReader = new FileReader(f1);
			BufferedReader bReader = new BufferedReader(frFileReader);
			String linea = bReader.readLine();
			System.out.println(linea);
			
			
			
			FileReader fr = new FileReader(f2);
			BufferedReader br = new BufferedReader(fr);
			String linea2 = br.readLine();
			System.out.println(linea2);
			
			
			frFileReader.close();
			bReader.close();
			fr.close();
			br.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
