package acts;

import java.util.Iterator;

public class Caracol_3 implements Runnable {

	public Caracol_3(double velocidad, String nombre) {
		super();
		this.velocidad = velocidad;
		this.nombre = nombre;
	}

	private double distancia = 1;
	private double velocidad;
	private String nombre;

	@Override
	public void run() {
		double avance = 0;
		double porcentaje = 0;

		System.out.println(nombre + "inicia la carrera");

		do {
			avance += velocidad * 1;
			porcentaje = 100 * avance / distancia;
			System.out.println(nombre + ">" + String.format("%.0f", porcentaje) + "%");
			try {
				Thread.sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} while (avance < distancia);

		System.out.println("--> " + nombre + " ha llegado a la meta");
	}

}