package acts;

public class ej7 {

	public static void main(String[] args) {


		
		String[] arrayNombres = {"metralletas", "tanis","reddit"};
		double[] arrayVelocidades = {Math.random(),Math.random(),Math.random()};
		
		Caracol c;
		Thread hiloCaracol;
		for (int i = 0; i < 3; i++) {
			c = new Caracol(arrayVelocidades[i], arrayNombres[i]);
			hiloCaracol = new Thread(c);
			hiloCaracol.start();
		}

	}

}
