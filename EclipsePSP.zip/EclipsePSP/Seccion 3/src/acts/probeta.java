package acts;

import java.util.LinkedList;

public class probeta {
	public static class PC {
		// Crea una lista compartida de tamanyo <capacity>
		LinkedList<Integer> listaProductos = new LinkedList<>();
		int capacidad = 2;

		// Funcion del productor
		public void produce() throws InterruptedException {
			int valor = 0;
			while (true) {
				synchronized (this) {
					// El hilo productor espera mientras la lista este llena
					while (listaProductos.size() == capacidad)
						wait();
					// Insertar el producto en la lista
					listaProductos.add(valor++);
					System.out.println(
							"Productor produjo: item nº " + valor + "(stock  " + listaProductos.size() + " productos)");
					// Notifica al consumidor que empiece a consumir
					notify();
					// Pausa para ver el proceso paso a paso
					Thread.sleep(1000);
				}
			}
		}
		

		// Funcion del consumidor
		public void consume() throws InterruptedException {
			while (true) {
				synchronized (this) {
					// El hilo consumidor espera mientras la lista este vacia
					while (listaProductos.size() == 0)
						wait();
					// Retira el primer producto de la lista
					int valor = listaProductos.removeFirst();
					System.err.println(
							"Consumidor consumio: item nº " + valor + "(stock" + listaProductos.size() + "productos)");
					// Despierta al hilo productor
					notify();
					// Pausa para ver el proceso paso a paso
					Thread.sleep(1000);
				}
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		// Crea la cola y los hilos productor
		// y consumidor
		final PC pc = new PC();
		// Hilo productor
		Thread t1 = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					pc.produce();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		// Hilo consumidor
		Thread t2 = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					pc.consume();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		});
		// Iniciar los hilos
		t1.start();
		t2.start();
		// Finalizar hilos, t1 antes que t2
		t1.join();
		t2.join();
	}
}
