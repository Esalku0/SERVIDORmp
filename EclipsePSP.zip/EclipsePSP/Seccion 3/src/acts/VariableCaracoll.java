package acts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class VariableCaracoll implements Runnable {

	double distancia = 1, velocidad;
	String nombre;
	static String nombreFicheroLlegada = "./caragolets.txt";

	VariableCaracoll(String name, double speed) {
		this.nombre = name;
		this.velocidad = speed;
	}

	public static void main(String[] args) {


		String[] arrayNombres = { "ThunderMol", "Rayo McMean", "Speed of Might", "Speedy Quizales", "The Flash" };
		double[] arrayVelocidades = { 0.1, 0.2, 0.3, 0.04, 0.005 };
		int[] arrayPrioridades = { 1, 2, 3, 4, 10 };
		VariableCaracoll objCaracol;
		Thread hiloCaracol;
		for (int i = 0; i < 5; i++) {
			objCaracol = new VariableCaracoll(arrayNombres[i], arrayVelocidades[i]);
			hiloCaracol = new Thread(objCaracol);
			hiloCaracol.setPriority(arrayPrioridades[i]);
			hiloCaracol.start();
		}

	}

	@Override
	public void run() {
		File ficheroLlegada = new File(nombreFicheroLlegada);
		double avance = 0;
		double porcentaje = 0;
		System.out.println(nombre + " inicia la carrera");
		if(ficheroLlegada.exists()) {
			System.out.println(nombre + " > Alguien ha ganado la carrera ... abondono en el " + String.format("%.0f", porcentaje) + " %");
			avance=distancia;
		} else {
			avance += velocidad * 1;
			porcentaje = 100 * avance / distancia;
			System.out.println(nombre + " > " + String.format("%.0f", porcentaje ) + "%");
		}
		
		
		boolean ficheroExiste = false;
		FileReader fr;
		while (!ficheroExiste) {
			try {
				fr = new FileReader(ficheroLlegada);
				BufferedReader br = new BufferedReader(fr);
				FileWriter fW = new FileWriter(ficheroLlegada);
				System.err.println("Carrera finalizada: ha ganado " + nombre);
				fW.write(nombre);
				br.close();
				fr.close();
				fW.close();
				ficheroExiste = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
