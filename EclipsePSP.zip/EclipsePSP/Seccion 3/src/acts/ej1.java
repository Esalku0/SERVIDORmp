package acts;

public class ej1 {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MostrarAscii op;
		for (int i = 0; i <= 2; i++) {
			op = new MostrarAscii(0);
			Thread hilo = new Thread(op);
			hilo.start();
		}
	}
}