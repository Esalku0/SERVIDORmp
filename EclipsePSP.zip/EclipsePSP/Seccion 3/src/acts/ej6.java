package acts;

public class ej6 {
	public static class semaforo {
		int semaforo = 1;
		int tiempo = 5000;

		public void encenderSemaforo1() throws InterruptedException {

			while (true) {
				synchronized (this) {
					try {
						while (semaforo == 2)
							wait();
						System.err.println("El semaforo 2 se ha puesto en rojo");
						System.out.println("El semaforo 1 se ha puesto en verde " + tiempo / 1000 + "segundos");
						System.out.println("---------------------------------");
						Thread.sleep(tiempo);
						semaforo = 2;
						notify();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}

		public void encenderSemaforo2() throws InterruptedException {

			while (true) {
				synchronized (this) {
					try {
						while (semaforo == 1)
							wait();
						System.err.println("El semaforo 1 se ha puesto en rojo");
						System.out.println("El semaforo 2 se ha puesto en verde " + tiempo / 1000 + "segundos");
						System.out.println("---------------------------------");
						Thread.sleep(tiempo);	
						semaforo = 1;
						notify();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		}

	public static void main(String[] args) throws InterruptedException {

		do {

			semaforo sem = new semaforo();
			Thread t1 = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						sem.encenderSemaforo1();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			Thread t2 = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						sem.encenderSemaforo2();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			});

			t1.start();
			t2.start();

			t1.join();
			t2.join();

		} while (true);
	}
}
}
