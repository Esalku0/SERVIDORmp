package acts;

import java.util.Iterator;

public class prueba implements Runnable {

	private int maximoalitas=100;
	private static int alitastotales=0;
	
	synchronized public void consumirAlita(int num) {
		if (num<=maximoalitas) {
			maximoalitas= maximoalitas - num;
			alitastotales = alitastotales + num;
			System.out.println("Se han comido " + num + "alitas");
		}else {
			System.out.println("no quedan alitas");
		}
	}
	
	public void run() {
		int alitas = (int) (Math.random() * 10 + 1);
		consumirAlita(alitas);
		
	}
	
	
	public static void main(String[] args) {
		Alitas picante = new Alitas();
		Thread t;
		for (int i = 0; i < 30; i++) {
			t = new Thread(picante);
			t.setName("Amigo " + (i + 1));
			t.start();
		}
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Total de alitas comidas: " + alitastotales);

	}
	

}
