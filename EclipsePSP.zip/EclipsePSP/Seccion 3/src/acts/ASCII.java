package acts;

public class ASCII implements Runnable {

	int tipo;
	ASCII(int tipo){
		
		this.tipo=tipo;
	}
	
	public static void main(String[] args) {
		ASCII object1= new ASCII(1);
		ASCII object2= new ASCII(2);
		Thread thread1= new Thread(object1);
		Thread thread2= new Thread (object2);
		thread1.start();
		thread2.start();
	}
	@Override
	public void run() {
		if(tipo==1) {
			for(int i=1;i<256;i+=2) {
				System.err.println("Caracter impar nº " + i + ": " + (char)i);
			}
		}else if(tipo==2){
			for(int i=2;i<=256;i+=2) {
				System.err.println("Caracter par nº " + i + ": " + (char)i);
			}
		}
		
	}

}
