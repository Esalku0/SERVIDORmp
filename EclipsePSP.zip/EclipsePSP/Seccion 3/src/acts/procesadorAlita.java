package acts;

public class procesadorAlita {


	public static void main(String[] args) {
		System.out.println("comiendo alita de putero");
		claseAleta picante = new claseAleta();
		Thread t;
for (int i = 0; i < 30; i++) {
	t = new Thread(picante);
	t.start();
}

		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}