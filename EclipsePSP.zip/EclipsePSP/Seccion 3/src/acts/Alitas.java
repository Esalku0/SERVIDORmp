package acts;

public class Alitas implements Runnable {

	int alitasDisponibles = 100;
	static int alitasConsumidas = 0;

	synchronized public void consumirAlita(String nombre, int alitas) {
		if (alitas <= alitasDisponibles) {
			System.out.println(alitas + " alitas se come " + nombre);
			alitasDisponibles = alitasDisponibles - alitas;
			alitasConsumidas = alitasConsumidas + alitas;
		} else {
			System.out.println(nombre + " quiere " + alitas + " alitas, pero no quedan alitas suficientes");
		}
	}

	@Override
	public void run() {
		String nombre = Thread.currentThread().getName();
		int alitas = (int) (Math.random() * 10 + 1);
		consumirAlita(nombre, alitas);

	}

	public static void main(String[] args) {
		Alitas picante = new Alitas();
		Thread t;
		for (int i = 0; i < 30; i++) {
			t = new Thread(picante);
			t.setName("Amigo " + (i + 1));
			t.start();
		}
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Total de alitas comidas: " + alitasConsumidas);
	}

}
