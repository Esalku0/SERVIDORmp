package acts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class VariableCaracol implements Runnable {

	double distancia = 1, velocidad;
	String nombre;
	static String nombreFicheroLlegada = "ficheroLlegada.txt";

	VariableCaracol(String name, double speed) {
		this.nombre = name;
		this.velocidad = speed;
	}

	public static void main(String[] args) {
		File ficheroLlegada = new File(nombreFicheroLlegada);
		if (ficheroLlegada.exists()) {
			ficheroLlegada.delete();
		}
	

		String[] arrayNombres = { "ThunderMol", "Rayo McMean", "Speed of Might", "Speedy Quizales", "The Flush" };
		double[] arrayVelocidades = { 0.1, 0.2, 0.3, 0.04, 0.005 };
		int[] arrayPrioridades = { 1, 2, 3, 4, 10 };
		VariableCaracol objCaracol;
		Thread hiloCaracol;
		for (int i = 0; i < 5; i++) {
			objCaracol = new VariableCaracol(arrayNombres[i], arrayVelocidades[i]);
			hiloCaracol = new Thread(objCaracol);
			hiloCaracol.setPriority(arrayPrioridades[i]);
			hiloCaracol.start();
		}
		boolean ficheroExiste = true;
		FileReader fr;
		while (!ficheroExiste) {
			try {
				fr = new FileReader(ficheroLlegada);
				BufferedReader br = new BufferedReader(fr);
				String nombre;
				nombre = br.readLine();
				System.err.println("Carrera finalizada: ha ganado " + nombre);
				br.close();
				fr.close();
				ficheroExiste = true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@Override
	public void run() {
		File ficheroLlegada = new File (nombreFicheroLlegada);
		double avance = 0;
		double porcentaje = 0;
		System.out.println(nombre + " inicia la carrera");
		if(ficheroLlegada.exists()) {
			System.out.println(nombre + " > Alguien ha ganado la carrera ... abondono en el " + String.format("%.0f", porcentaje) + " %");
			avance=distancia;
		} else {
			avance += velocidad * 1;
			porcentaje = 100 * avance / distancia;
			System.out.println(nombre + " > " + String.format("%.0f", porcentaje ) + "%");
			
		}
		if(!ficheroLlegada.exists()) {
			FileWriter fw;
			try {
				fw = new FileWriter(ficheroLlegada);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(nombre);
				bw.close();
				fw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.err.println(nombre + "he ganao chupala");
		}
	}

}
