package acts;

public class ej5 {

	public static void main(String[] args) {
		KFC k = new KFC();
		Thread t;
		for (int i = 0; i < 100; i++) {
			t = new Thread(k);
			t.setName("Alumno " + (i + 1));
			t.start();
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		} // Pausa para dejar que acaben todos los threads
		System.out.println("Total de alitas restantes: " + k.numAlitas);
	}

}
