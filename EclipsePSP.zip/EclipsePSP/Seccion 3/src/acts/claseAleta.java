package acts;

public class claseAleta implements Runnable{
	
	int alitasDisponibles = 100;
	static int alitasConsumidas = 0;
	int cantidad;


	synchronized public void consumirAlita(int cantidad) {
		if (cantidad <= alitasDisponibles) {
			System.out.println(cantidad + " alitas se come ");
			alitasDisponibles = alitasDisponibles - cantidad;
			alitasConsumidas = alitasConsumidas + cantidad;
		} else {
			System.out.println(" quiere " + cantidad + " alitas, pero no quedan alitas suficientes");
		}
	}

	@Override
	public void run() {
		String nombre = Thread.currentThread().getName();
		int alitas = (int) (Math.random() * 10 + 1);
		consumirAlita(alitas);

	}
}
