//package acts;
//
//public class probeta2 {
//
//	public static void main(String[] args) {
//		probeta s = new probeta();
//		Thread t;
//		for (int i = 0; i < 100; i++) {
//			t = new Thread(s);
//			t.setName("Cliente " + (i + 1));
//			t.start();
//		}
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//// TODO Auto-generated catch block
//			e.printStackTrace();
//		} // Pausa para dejar que acaben todos los threads
//		System.out.println("Total entradas vendidas: " + s.entradasVendidas);
//	}
//}
