package acts;


//Implementa una clase denominada “Contador” que implemente Runnable con tres 
//atributos: un atributo de tipo String denominado “nombreHilo”, otro atributo de tipo entero 
//denominado “inicioContador” y otro de tipo entero denominado “limiteContador”, que 
//indicará el fin de la cuenta. El programa principal deberá crear 5 hilos contadores con límites 
//distintos y que se muestre por pantalla la cuenta de cada uno.


public class Contador implements Runnable {

	int initContador, limitContador;
	String nombreHilo;

	Contador(int inicioContador, int limiteContador, String nomHilo) {
		this.initContador = inicioContador;
		this.limitContador = limiteContador;
		this.nombreHilo = nomHilo;
	}
	
	@Override
	public void run() {
		for (int i = initContador; i <= limitContador; i++) {
			System.out.println("Contador " + nombreHilo + " (de  " + initContador + " a " + limitContador + " ): " + i);
		}

	}

	public static void main(String[] args) {
		String[] arrayHilos = { "h1", "h2", "h3", "h4", "h5" };
		int[] arrayInicio = { 1, 11, 21, 31, 41 };
		int[] arrayLimite = { 10, 20, 30, 40 };
		Contador objContador;
		Thread hiloContador;
		for (int i = 0; i < 5; i++) {
			objContador = new Contador(arrayInicio[i], arrayLimite[i], arrayHilos[i]);
			hiloContador = new Thread(objContador);
			hiloContador.start();
		}
	}
}
