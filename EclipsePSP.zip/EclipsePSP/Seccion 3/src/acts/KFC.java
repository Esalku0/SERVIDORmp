package acts;

import java.util.Iterator;

public class KFC implements Runnable {

	int numAlitas = 100;


	synchronized private void consumirAlita(String nombre, int consum) {
//	 private void consumirAlita(String nombre, int consum) {
		if (consum <= numAlitas) {
			System.out.println("El alumno " + nombre + " ha peedido " + consum + " alitas");
			numAlitas = numAlitas - consum;
		} else {
			System.out.println("No quedan alitas, alitas disponibles: " + numAlitas);
		}
	}

	public void run() {
		String nombre = Thread.currentThread().getName();
		int cantidad = (int) (Math.random() * 10 + 1);
		consumirAlita(nombre, cantidad);

	}

}
