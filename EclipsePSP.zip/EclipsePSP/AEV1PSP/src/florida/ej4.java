//package florida;
//
//import java.util.Scanner;
//
//public class ej4 {
//
//	public static void main(String[] args) {
//
//		Caracol c;
//		
//		for (int i = 0; i <= 5; i++) {
//			int numeroAleatorio = (int) (Math.random()*10+1);
//			c = new Caracol(numeroAleatorio,"Pepe"+ i);
//			Thread hilo = new Thread(c);
//			 hilo.setPriority(numeroAleatorio);  
//			hilo.start();
//		}
//
//	
////		       double resultado = (porcent / 100) * cant;
////		        System.out.println("El "+porcent+"% de "+cant+" es: "+resultado);
//		    
//	}
//
//}
