package florida;

public class Contador implements Runnable {

	private String nombreHilo;
	private int inicioContador;
	private int limiteContador;

	public Contador(String nombreHilo, int inicioContador, int limiteContador) {
		super();
		this.nombreHilo = nombreHilo;
		this.inicioContador = inicioContador;
		this.limiteContador = limiteContador;
	}

	public void run() {

		for (int i = 0; i < limiteContador; i++) {
			inicioContador++;
			System.out.println(
					"El hilo " + this.nombreHilo + " esta en el numero " + inicioContador + " de " + limiteContador);
		}

	}

}
