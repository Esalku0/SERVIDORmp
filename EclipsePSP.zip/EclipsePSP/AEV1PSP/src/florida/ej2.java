package florida;

import java.util.Iterator;

public class ej2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Contador c;
		
		for (int i = 0; i < 5; i++) {
			int numeroAleatorio = (int) (Math.random()*25+1);
			c = new Contador("Juan" + i, 5, numeroAleatorio);
			Thread hilo = new Thread(c);
			hilo.start();
		}
		
		
		
	}

}
