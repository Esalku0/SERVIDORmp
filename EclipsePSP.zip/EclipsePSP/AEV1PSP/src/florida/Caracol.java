package florida;

public class Caracol implements Runnable {
    String nombre;
    double distancia = 1, velocidad;

    public Caracol(String nombre, double velocidad) {
        this.nombre = nombre;
        this.velocidad = velocidad;
    }

    public static void main(String[] args) {
        String[] arrNombres = { "Turbo", "Rayo", "Flash", "LightSpeed", "Aigua" };
        double[] arrVelocidad = { 0.01, 0.011, 0.0099, 0.00999, 0.0105 };
        Caracol objetoCaracol;
        Thread hiloCaracol;
        for (int i = 0; i < 5; i++) {
            objetoCaracol = new Caracol(arrNombres[i], arrVelocidad[i]);
            hiloCaracol = new Thread(objetoCaracol);
            hiloCaracol.start();

        }

    }

    @Override
    public void run() {
        double avance = 0;
        double porcentaje = 0;
        System.out.println(nombre + " inicia la carrera");
        while (avance < distancia) {
            avance += velocidad * 1;
            porcentaje = 100 * avance / distancia;
            System.out.println(nombre + " > " + String.format("%.0f", porcentaje) + "%");
            try {
                Thread.sleep(200);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println(" -> ¡¡¡" + nombre + " ha llegado a la meta!!!");
    }

}