package florida;

public class ej6 {
	public static class semaforo {
		int semaforo1 = 1;
		int semaforo2 = 0;

		public void encenderSemaforo1() throws InterruptedException {

			while (true) {
				synchronized (this) {
					if (semaforo1 == 1) {

						wait();
						System.out.println("El semaforo 1 se ha puesto en verde");
						semaforo1=0;
						semaforo2=1;
						System.err.println("El semaforo 2 se ha puesto en Rojo");
						notify();

					}
					Thread.sleep(1000);
				}
			}
		}

		public synchronized void encenderSemaforo2() throws InterruptedException {

			while (true) {
				synchronized (this) {

					if (semaforo2 == 1) {
						wait();
						System.out.println("El semaforo 2 se ha puesto en verde");
						semaforo1=1;
						semaforo2=0;
						System.err.println("El semaforo 1 se ha puesto en Rojo");
						notifyAll();
					}

					Thread.sleep(1000);
				}
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {

		do {

			semaforo sem = new semaforo();
			Thread t1 = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						sem.encenderSemaforo1();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			Thread t2 = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						sem.encenderSemaforo2();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			});

			t1.start();
			t2.start();

			t1.join();
			t2.join();

		} while (true);
	}
}
