package florida;

import java.util.Iterator;

public class Caracol_2 implements Runnable {

	public Caracol_2(double velocidad, String nombre) {
		super();
		this.velocidad = velocidad;
		this.nombre = nombre;
	}

	private double velocidad;
	private String nombre;

	@Override
	public void run() {
		int limite = 10;

		int numeroAleatorio = (int) (Math.random() * 100 + 1);
		for (int i = 0; i < limite; i++) {
			double porcentaje = (i * 100 / limite);
			

			System.out.println("El Caracol"+nombre+" esta en un = " + porcentaje + "% de la carrera");
		}

	}

}